#!/usr/bin/env python
# coding: utf-8

# In[172]:


# Jump-Start Example: Python analysis of MSPA Software Survey

# Update 2017-09-21 by Tom Miller and Kelsey O'Neill
# Update 2018-06-30 by Tom Miller v005 transformation code added

# tested under Python 3.6.1 :: Anaconda custom (x86_64)
# on Windows 10.0 and Mac OS Sierra 10.12.2 

# shows how to read in data from a comma-delimited text file
# manipuate data, create new count variables, define categorical variables,
# work with dictionaries and lambda mapping functions for recoding data 

# visualizations in this program are routed to external pdf files
# so they may be included in printed or electronic reports

# prepare for Python version 3x features and functions
# these two lines of code are needed for Python 2.7 only
# commented out for Python 3.x versions
# from __future__ import division, print_function
# from future_builtins import ascii, filter, hex, map, oct, zip

# external libraries for visualizations and data manipulation
# ensure that these packages have been installed prior to calls
import pandas as pd  # data frame operations  
import numpy as np  # arrays and math functions
import matplotlib.pyplot as plt  # static plotting
import seaborn as sns  # pretty plotting, including heat map
import os 
import reportlab 

os.getcwd()
os.chdir('C:\\Users\\R\\Desktop\\MSDS 422\\Labs\\mspa-software-survey-case-python-v005')


# In[45]:


# correlation heat map setup for seaborn
def corr_chart(df_corr):
    corr=df_corr.corr()
    #screen top half to get a triangle
    top = np.zeros_like(corr, dtype=np.bool)
    top[np.triu_indices_from(top)] = True
    fig=plt.figure()
    fig, ax = plt.subplots(figsize=(12,12))
    sns.heatmap(corr, mask=top, cmap='coolwarm', 
        center = 0, square=True, 
        linewidths=.5, cbar_kws={'shrink':.5}, 
        annot = True, annot_kws={'size': 9}, fmt = '.3f')           
    plt.xticks(rotation=45) # rotate variable labels on columns (x axis)
    plt.yticks(rotation=0) # use horizontal variable labels on rows (y axis)
    plt.title('Correlation Heat Map')   
    plt.savefig('plot-corr-map.pdf', 
        bbox_inches = 'tight', dpi=None, facecolor='w', edgecolor='b', 
        orientation='portrait', papertype=None, format=None, 
        transparent=True, pad_inches=0.25, frameon=None)      

np.set_printoptions(precision=3)


# In[ ]:


# read in comma-delimited text file, creating a pandas DataFrame object
# note that IPAddress is formatted as an actual IP address
# but is actually a random-hash of the original IP address

import pandas
df = pandas.read_csv('mspa-survey-data.csv')
valid_survey_input = pd.read_csv('mspa-survey-data.csv')

# use the RespondentID as label for the rows... the index of DataFrame
valid_survey_input.set_index('RespondentID', drop = True, inplace = True)

# examine the structure of the DataFrame object
print('\nContents of initial survey data ---------------')


# In[29]:


# could use len() or first index of shape() to get number of rows/observations
print('\nNumber of Respondents =', len(valid_survey_input)) 

# show the column/variable names of the DataFrame

# note that RespondentID is no longer present
print(valid_survey_input.columns)


# In[157]:


# abbreviated printing of the first five rows of the data frame
print(pd.DataFrame.head(valid_survey_input)) 


# In[22]:


# shorten the variable/column names for software preference variables
survey_df = valid_survey_input.rename(index=str, columns={
    'Personal_JavaScalaSpark': 'My_Java',
    'Personal_JavaScriptHTMLCSS': 'My_JS',
    'Personal_Python': 'My_Python',
    'Personal_R': 'My_R',
    'Personal_SAS': 'My_SAS',
    'Professional_JavaScalaSpark': 'Prof_Java',
    'Professional_JavaScriptHTMLCSS': 'Prof_JS',
    'Professional_Python': 'Prof_Python',
    'Professional_R': 'Prof_R',
    'Professional_SAS': 'Prof_SAS',
    'Industry_JavaScalaSpark': 'Ind_Java',
    'Industry_JavaScriptHTMLCSS': 'Ind_JS',
    'Industry_Python': 'Ind_Python',
    'Industry_R': 'Ind_R',
    'Industry_SAS': 'Ind_SAS'})
    


# In[ ]:


# define subset DataFrame for analysis of software preferences 
software_df = survey_df.loc[:, 'My_Java':'Ind_SAS']

#remove outliers from software preferences data frame
software_df_new = software_df[np.abs(software_df - software_df.mean()) <= (3 * software_df.std())]

 


# In[31]:


#define subset DataFrame for analysis of courses completed
courses_completed_df = survey_df.loc[:, 'PREDICT453': 'PREDICT457'].dropna(how='all')


# In[39]:


#define subset DataFrame for analysis of potential new course preference
new_course_interest_df = survey_df.loc[:, 'Python_Course_Interest': 'Systems_Analysis_Course_Interest'].dropna(how='all')

#remove outliers from potential new course preference data frame
new_course_interest_df_new = new_course_interest_df[np.abs(new_course_interest_df - new_course_interest_df.mean()) <= (3 * new_course_interest_df.std())]


# #calculate summary statistics of software preferences
# software_df_new.describe()
# print(software_df_new.describe())
# 

# In[68]:


#calculate skewness of distribution for software preferences
software_df_new.skew()
print(software_df_new.skew())


# In[69]:


#calculate kurtosis of distribution for software preferences
software_df_new.kurtosis()
print(software_df_new.kurtosis())


# In[78]:


#calculate summary statistics of potential new course preference
new_course_interest_df_new.describe()
print(new_course_interest_df_new.describe())


# In[71]:


#calculate skewness of distribution for potential new course preference
new_course_interest_df_new.skew()
print(new_course_interest_df_new.skew())


# In[72]:


#calculate kurtosis of distribution for potential new course preference
new_course_interest_df_new.kurtosis()
print(new_course_interest_df_new.kurtosis())


# In[169]:


#create a boxplot for software preferences
plt.figure(figsize = (15,5))
sns.boxplot(data=software_df_new)
plt.title("Boxplot of Software Preferences")
plt.show()
plt.close()


# In[56]:


# create a set of scatter plots for personal software preferences
for i in range(5):
    for j in range(5):
        if i != j:
            file_title = survey_df.columns[i] + '_and_' + survey_df.columns[j]
            plot_title = survey_df.columns[i] + ' and ' + survey_df.columns[j]
            fig, axis = plt.subplots()
            axis.set_xlabel(survey_df_labels[i])
            axis.set_ylabel(survey_df_labels[j])
            plt.title(plot_title)
            scatter_plot = axis.scatter(survey_df[survey_df.columns[i]], 
            survey_df[survey_df.columns[j]],
            facecolors = 'none', 
            edgecolors = 'blue') 
            plt.savefig(file_title + '.pdf', 
                bbox_inches = 'tight', dpi=None, facecolor='w', edgecolor='b', 
                orientation='portrait', papertype=None, format=None, 
                transparent=True, pad_inches=0.25, frameon=None)  


# In[73]:


#create a set of scatter plots for professional software preferences

for i in range(6,11):
    for j in range(6,11):
        if i != j:
            file_title = survey_df.columns[i] + '_and_' + survey_df.columns[j]
            plot_title = survey_df.columns[i] + ' and ' + survey_df.columns[j]
            fig, axis = plt.subplots()
            axis.set_xlabel(survey_df_labels[i])
            axis.set_ylabel(survey_df_labels[j])
            plt.title(plot_title)
            scatter_plot = axis.scatter(survey_df[survey_df.columns[i]], 
            survey_df[survey_df.columns[j]],
            facecolors = 'none', 
            edgecolors = 'red') 
            plt.savefig(file_title + '.pdf', 
                bbox_inches = 'tight', dpi=None, facecolor='w', edgecolor='b', 
                orientation='portrait', papertype=None, format=None, 
                transparent=True, pad_inches=0.25, frameon=None)  


# In[76]:


#create a set of scatter plots for industry software preferences
for i in range(11,15):
    for j in range(11,15):
        if i != j:
            file_title = survey_df.columns[i] + '_and_' + survey_df.columns[j]
            plot_title = survey_df.columns[i] + ' and ' + survey_df.columns[j]
            fig, axis = plt.subplots()
            axis.set_xlabel(survey_df_labels[i])
            axis.set_ylabel(survey_df_labels[j])
            plt.title(plot_title)
            scatter_plot = axis.scatter(survey_df[survey_df.columns[i]], 
            survey_df[survey_df.columns[j]],
            facecolors = 'none', 
            edgecolors = 'green') 
            plt.savefig(file_title + '.pdf', 
                bbox_inches = 'tight', dpi=None, facecolor='w', edgecolor='b', 
                orientation='portrait', papertype=None, format=None, 
                transparent=True, pad_inches=0.25, frameon=None)  


# In[112]:


#calculate totals for personal software preferences
my_python_preference = software_df_new['My_Python'].sum()
my_r_preference = software_df_new['My_R'].sum()
my_sas_preference = software_df_new['My_SAS'].sum()
my_js_preference = software_df_new['My_JS'].sum()
my_java_preference = software_df_new['My_Java'].sum()

#calculate total value for personal software preferences
my_software_preference_total = my_python_preference + my_r_preference + my_sas_preference + my_js_preference + my_java_preference

#calculate total personal software preference percentages 
my_python_percentage = my_python_preference/my_software_preference_total *100
my_r_percentage = my_r_preference/my_software_preference_total *100
my_sas_percentage = my_sas_preference/my_software_preference_total *100
my_js_percentage = my_js_preference/my_software_preference_total *100
my_java_percentage = my_java_preference/my_software_preference_total *100

#create variable for total personal software preferences
total_personal_software_percentages = my_python_percentage, my_r_percentage, my_sas_percentage, my_js_percentage, my_java_percentage

#create a pie chart to visualize personal software preferences
labels = ['Python','R','SAS','JavaScript','Java']
colors = ['blue','yellow','green','red','purple']
plt.pie(total_personal_software_percentages, labels = labels, colors = colors, startangle = 90, autopct='%1.0f%%')
plt.title("Personal Software Preferences (in %)")
plt.show()


# In[113]:


#calculate totals for professional software preferences
prof_python_preference = software_df_new['Prof_Python'].sum()
prof_r_preference = software_df_new['Prof_R'].sum()
prof_sas_preference = software_df_new['Prof_SAS'].sum()
prof_js_preference = software_df_new['Prof_JS'].sum()
prof_java_preference = software_df_new['Prof_Java'].sum()

#calculate total value for professional software preferences
prof_software_preference_total = prof_python_preference + prof_r_preference + prof_sas_preference + prof_js_preference + prof_java_preference

#calculate total personal software preference percentages 
prof_python_percentage = prof_python_preference/prof_software_preference_total *100
prof_r_percentage = prof_r_preference/prof_software_preference_total *100
prof_sas_percentage = prof_sas_preference/prof_software_preference_total *100
prof_js_percentage = prof_js_preference/prof_software_preference_total *100
prof_java_percentage = prof_java_preference/prof_software_preference_total *100

#create variable for total professional software preferences
total_prof_software_percentages = prof_python_percentage, prof_r_percentage, prof_sas_percentage, prof_js_percentage, prof_java_percentage

#create a pie chart to visualize professional software preferences
labels = ['Python','R','SAS','JavaScript','Java']
colors = ['blue','yellow','green','red','purple']
plt.pie(total_prof_software_percentages, labels = labels, colors = colors, startangle = 90, autopct='%1.0f%%')
plt.title("Professional Software Preferences (in %)") 
plt.show()


# In[114]:


#calculate totals for indsutry software preferences
ind_python_preference = software_df_new['Ind_Python'].sum()
ind_r_preference = software_df_new['Ind_R'].sum()
ind_sas_preference = software_df_new['Ind_SAS'].sum()
ind_js_preference = software_df_new['Ind_JS'].sum()
ind_java_preference = software_df_new['Ind_Java'].sum()

#calculate total value for professional software preferences
ind_software_preference_total = ind_python_preference + ind_r_preference + ind_sas_preference + ind_js_preference + ind_java_preference

#calculate personal software preference percentages 
ind_python_percentage = ind_python_preference/ind_software_preference_total *100
ind_r_percentage = ind_r_preference/ind_software_preference_total *100
ind_sas_percentage = ind_sas_preference/ind_software_preference_total *100
ind_js_percentage = ind_js_preference/ind_software_preference_total *100
ind_java_percentage = ind_java_preference/ind_software_preference_total *100

#create variable for total professional software preferences
total_ind_software_percentages = ind_python_percentage, ind_r_percentage, ind_sas_percentage, ind_js_percentage, ind_java_percentage

#create a pie chart to visualize industry software preferences
labels = ['Python','R','SAS','JavaScript','Java']
colors = ['blue','yellow','green','red','purple']
plt.pie(total_ind_software_percentages, labels = labels, colors = colors, startangle = 90, autopct='%1.0f%%')
plt.title("Industry Software Preferences (in %)") 
plt.show()


# In[164]:


#create a boxplot of new course interests
plt.figure(figsize = (15,5))
sns.boxplot(data=new_course_interest_df_new)
plt.title("Boxplot of New Course Interest")
plt.show()
plt.close()


# In[117]:


#calculate totals for new course preferences
course_interest_python_total = survey_df['Python_Course_Interest'].sum()
course_interest_foundations_de_total = survey_df['Foundations_DE_Course_Interest'].sum()
course_interest_analytics_app_total = survey_df['Analytics_App_Course_Interest'].sum()
course_interest_systems_analysis_total = survey_df['Systems_Analysis_Course_Interest'].sum()

#calculate total value of new course preferences
total_course_interest_value = course_interest_python_total + course_interest_foundations_de_total + course_interest_analytics_app_total + course_interest_systems_analysis_total

#calculate new course interest percentages
course_interest_python_percentage = course_interest_python_total/total_course_interest_value *100 
course_interest_foundations_de_percentage = course_interest_foundations_de_total/total_course_interest_value *100
course_interest_analytics_app_percentage = course_interest_analytics_app_total/total_course_interest_value *100
course_interest_systems_analysis_percentage = course_interest_systems_analysis_total/total_course_interest_value *100

#create a new variable for total course interest percentages
new_course_interest_percentages = course_interest_python_percentage, course_interest_foundations_de_percentage, course_interest_analytics_app_percentage, course_interest_systems_analysis_percentage

#create a pie chart to visualize course interest 
labels = ['Python','Foundations DE','Analytics App','Systems Analysis']
colors = ['lightseagreen','lightcoral','gold','darkmagenta']
plt.pie(new_course_interest_percentages, labels = labels, colors = colors, startangle = 90, autopct='%1.0f%%')
plt.title("New Course Interests (in %)") 
plt.show()


# In[134]:


#create variables for participants differentiated by graduation year
grad_year_2017_or_earlier = survey_df[(survey_df.Graduate_Date =='Fall 2017') | (survey_df.Graduate_Date == 'Fall 2016') | (survey_df.Graduate_Date == 'Winter 2017') | (survey_df.Graduate_Date == 'Summer 2017') | (survey_df.Graduate_Date == 'Spring 2017')]
grad_year_2018 = survey_df[(survey_df.Graduate_Date =='Fall 2018') | (survey_df.Graduate_Date == 'Winter 2018') | (survey_df.Graduate_Date == 'Spring 2018') | (survey_df.Graduate_Date == 'Summer 2018')]
grad_year_2019_or_later = survey_df[(survey_df.Graduate_Date =='Fall 2019') | (survey_df.Graduate_Date == 'Winter 2019') | (survey_df.Graduate_Date == 'Spring 2019') | (survey_df.Graduate_Date == 'Summer 2019') | (survey_df.Graduate_Date == '2020 or Later')]


# In[ ]:


#calculate summary statistics for particpants graduating in 2017 or earlier
print(grad_year_2017_or_earlier.describe())


# In[141]:


#calculate potential course interest for 2017 or earlier graduates 
course_interest_python_2017 = grad_year_2017_or_earlier['Python_Course_Interest'].sum()
course_interest_foundations_de_2017 = grad_year_2017_or_earlier['Foundations_DE_Course_Interest'].sum()
course_interest_analytics_app_2017 = grad_year_2017_or_earlier['Analytics_App_Course_Interest'].sum()
course_interest_systems_analysis_2017 = grad_year_2017_or_earlier['Systems_Analysis_Course_Interest'].sum()

#calculate total value of potential new course interests from 2017 or earlier graduates
total_course_interest_value_2017 = course_interest_python_2017 + course_interest_foundations_de_2017 + course_interest_analytics_app_2017 + course_interest_systems_analysis_2017

#calculate new course interest percentages
course_interest_python_percentage_2017 = course_interest_python_2017/total_course_interest_value_2017 *100 
course_interest_foundations_de_percentage_2017 = course_interest_foundations_de_2017/total_course_interest_value_2017 *100
course_interest_analytics_app_percentage_2017 = course_interest_analytics_app_2017/total_course_interest_value_2017 *100
course_interest_systems_analysis_percentage_2017 = course_interest_systems_analysis_2017/total_course_interest_value_2017 *100


#create a new variable of total course interest percentages for 2017 or earlier graduates
new_course_interest_percentages_2017 = course_interest_python_percentage_2017, course_interest_foundations_de_percentage_2017, course_interest_analytics_app_percentage_2017, course_interest_systems_analysis_percentage_2017

#create pie chart to visualize course interest from 2017 or earlier graduates
labels = ['Python','Foundations DE','Analytics App','Systems Analysis']
colors = ['lightseagreen','lightcoral','gold','darkmagenta']
plt.pie(new_course_interest_percentages_2017, labels = labels, colors = colors, startangle = 90, autopct='%1.0f%%')
plt.title("New Course Interests from Graduates in 2017 or Earlier (in %)") 
plt.show()


# In[136]:


#calculate summary statistics for participants graduating in 2018
print(grad_year_2018.describe())


# In[142]:


#calculate potential course interest for 2018 graduates 
course_interest_python_2018 = grad_year_2018['Python_Course_Interest'].sum()
course_interest_foundations_de_2018 = grad_year_2018['Foundations_DE_Course_Interest'].sum()
course_interest_analytics_app_2018 = grad_year_2018['Analytics_App_Course_Interest'].sum()
course_interest_systems_analysis_2018 = grad_year_2018['Systems_Analysis_Course_Interest'].sum()

#calculate total value of potential new course interests from 2018 graduates
total_course_interest_value_2018 = course_interest_python_2018 + course_interest_foundations_de_2018 + course_interest_analytics_app_2018 + course_interest_systems_analysis_2018

#calculate new course interest percentages
course_interest_python_percentage_2018 = course_interest_python_2017/total_course_interest_value_2018 *100 
course_interest_foundations_de_percentage_2018 = course_interest_foundations_de_2018/total_course_interest_value_2018 *100
course_interest_analytics_app_percentage_2018 = course_interest_analytics_app_2018/total_course_interest_value_2018 *100
course_interest_systems_analysis_percentage_2018 = course_interest_systems_analysis_2018/total_course_interest_value_2018 *100


#create a new variable of total course interest percentages for 2018 graduates
new_course_interest_percentages_2018 = course_interest_python_percentage_2018, course_interest_foundations_de_percentage_2018, course_interest_analytics_app_percentage_2018, course_interest_systems_analysis_percentage_2018

#create pie chart to visualize course interest from 2018 graduates
labels = ['Python','Foundations DE','Analytics App','Systems Analysis']
colors = ['lightseagreen','lightcoral','gold','darkmagenta']
plt.pie(new_course_interest_percentages_2018, labels = labels, colors = colors, startangle = 90, autopct='%1.0f%%')
plt.title("New Course Interests from Graduates in 2018 (in %)") 
plt.show()


# In[135]:


#calculate summary statistics for participants graduating in 2019 or later
print(grad_year_2019_or_later.describe())


# In[144]:


#calculate potential course interest for 2019 or later future graduates 
course_interest_python_2019 = grad_year_2019_or_later['Python_Course_Interest'].sum()
course_interest_foundations_de_2019 = grad_year_2019_or_later['Foundations_DE_Course_Interest'].sum()
course_interest_analytics_app_2019 = grad_year_2019_or_later['Analytics_App_Course_Interest'].sum()
course_interest_systems_analysis_2019 = grad_year_2019_or_later['Systems_Analysis_Course_Interest'].sum()

#calculate total value of potential new course interests from future 2019 or later graduates
total_course_interest_value_2019 = course_interest_python_2019 + course_interest_foundations_de_2019 + course_interest_analytics_app_2019 + course_interest_systems_analysis_2019

#calculate new course interest percentages
course_interest_python_percentage_2019 = course_interest_python_2019/total_course_interest_value_2019 *100 
course_interest_foundations_de_percentage_2019 = course_interest_foundations_de_2019/total_course_interest_value_2019 *100
course_interest_analytics_app_percentage_2019 = course_interest_analytics_app_2019/total_course_interest_value_2019 *100
course_interest_systems_analysis_percentage_2019 = course_interest_systems_analysis_2019/total_course_interest_value_2019 *100


#create a new variable of total course interest percentages for future 2019 or later graduates
new_course_interest_percentages_2019 = course_interest_python_percentage_2019, course_interest_foundations_de_percentage_2019, course_interest_analytics_app_percentage_2019, course_interest_systems_analysis_percentage_2019

#create pie chart to visualize course interest from future 2019 or later graduates
labels = ['Python','Foundations DE','Analytics App','Systems Analysis']
colors = ['lightseagreen','lightcoral','gold','darkmagenta']
plt.pie(new_course_interest_percentages_2019, labels = labels, colors = colors, startangle = 90, autopct='%1.0f%%')
plt.title("New Course Interests from Future Graduates in 2019 or Later (in %)") 
plt.show()


# In[62]:


# single scatter plot example
fig, axis = plt.subplots()
axis.set_xlabel('Personal Preference for R')
axis.set_ylabel('Personal Preference for Python')
plt.title('R and Python Perferences')
scatter_plot = axis.scatter(survey_df['My_R'], 
    survey_df['My_Python'],
    facecolors = 'none', 
    edgecolors = 'blue') 
plt.savefig('plot-scatter-r-python.pdf', 
    bbox_inches = 'tight', dpi=None, facecolor='w', edgecolor='b', 
    orientation='portrait', papertype=None, format=None, 
    transparent=True, pad_inches=0.25, frameon=None)  

survey_df_labels = [
    'Personal Preference for Java/Scala/Spark',
    'Personal Preference for Java/Script/HTML/CSS',
    'Personal Preference for Python',
    'Personal Preference for R',
    'Personal Preference for SAS',
    'Professional Java/Scala/Spark',
    'Professional JavaScript/HTML/CSS',
    'Professional Python',
    'Professional R',
    'Professional SAS',
    'Industry Java/Scala/Spark',
    'Industry Java/Script/HTML/CSS',
    'Industry Python',
    'Industry R',
    'Industry SAS'        
] 


# In[63]:


# examine intercorrelations among software preference variables
# with correlation matrix/heat map
corr_chart(df_corr = software_df) 

# descriptive statistics for software preference variables
print('\nDescriptive statistics for survey data ---------------')
print(software_df.describe())

# descriptive statistics for one variable
print('\nDescriptive statistics for courses completed ---------------')
print(survey_df['Courses_Completed'].describe())


# In[170]:


# transformation code added with version v005
# ----------------------------------------------------------
# transformations a la Scikit Learn
# documentation at http://scikit-learn.org/stable/auto_examples/
#                  preprocessing/plot_all_scaling.html#sphx-glr-auto-
#                  examples-preprocessing-plot-all-scaling-py
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler

# transformations a la Scikit Learn
# select variable to examine, eliminating missing data codes
X = survey_df['Courses_Completed'].dropna()


# In[171]:


# Seaborn provides a convenient way to show the effects of transformations
# on the distribution of values being transformed
# Documentation at https://seaborn.pydata.org/generated/seaborn.distplot.html

unscaled_fig, ax = plt.subplots()
sns.distplot(X).set_title('Unscaled')
unscaled_fig.savefig('Transformation-Unscaled' + '.pdf', 
    bbox_inches = 'tight', dpi=None, facecolor='w', edgecolor='b', 
    orientation='portrait', papertype=None, format=None, 
    transparent=True, pad_inches=0.25, frameon=None)  

standard_fig, ax = plt.subplots()
sns.distplot(StandardScaler().fit_transform(X)).set_title('StandardScaler')
standard_fig.savefig('Transformation-StandardScaler' + '.pdf', 
    bbox_inches = 'tight', dpi=None, facecolor='w', edgecolor='b', 
    orientation='portrait', papertype=None, format=None, 
    transparent=True, pad_inches=0.25, frameon=None)  

minmax_fig, ax = plt.subplots()
sns.distplot(MinMaxScaler().fit_transform(X)).set_title('MinMaxScaler')
minmax_fig.savefig('Transformation-MinMaxScaler' + '.pdf', 
    bbox_inches = 'tight', dpi=None, facecolor='w', edgecolor='b', 
    orientation='portrait', papertype=None, format=None, 
    transparent=True, pad_inches=0.25, frameon=None) 
 
log_fig, ax = plt.subplots()
sns.distplot(np.log(X)).set_title('NaturalLog')
log_fig.savefig('Transformation-NaturalLog' + '.pdf', 
    bbox_inches = 'tight', dpi=None, facecolor='w', edgecolor='b', 
    orientation='portrait', papertype=None, format=None, 
    transparent=True, pad_inches=0.25, frameon=None)  


# In[ ]:




